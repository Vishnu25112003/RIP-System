const hre = require("hardhat");

async function main() {
  // 1. Get the contract factory
  const Calculator = await hre.ethers.getContractFactory("Calculator");

  // 2. Deploy the contract (IMPORTANT: must use await here)
  const calculator = await Calculator.deploy();

  // 3. Wait for deployment to finish
  await calculator.waitForDeployment();

  // 4. Log the address
  console.log("✅ Calculator deployed at:", await calculator.getAddress());
}

main().catch((error) => {
  console.error("❌ Error during deployment:", error);
  process.exitCode = 1;
});
